<h1 class="mt-4">Kategori</h1>
<p class="page-sub">Kelompok koleksi buku.</p>
<div class="toolbar">
    <a href="?page=katagori_tambah" class="btn btn-primary">Tambah</a>
</div>
<div class="table-wrap">
        <table class="table table-bordered mb-0" id="dataTable" width="100%" cellspacing="0">
            <tr>
                <th>No</th>
                <th>Nama kategori</th>
                <th>Aksi</th>
            </tr>
            <?php
            $i = 1;
                $query = mysqli_query($koneksi, "SELECT*FROM katagori");
                while($data = mysqli_fetch_array($query)){
                    ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $data['katagori']; ?></td>
                        <td>
                            <a href="?page=katagori_ubah&&id=<?php echo $data['id_katagori']; ?>" class="btn btn-info">Ubah</a>
                            <a onclick="return confirm('Apakah anda yakin menghapus katagori ini?');" href="?page=katagori_hapus&&id=<?php echo $data['id_katagori']; ?>" class="btn btn-danger">Hapus</a>
                        </td>
                    </tr>
                    <?php
                }
            ?>
        </table>
</div>