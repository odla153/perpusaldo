<?php
    include "koneksi.php";
    session_start();
    if(!isset($_SESSION['user'])){
        header('location:login.php');
        exit;
    }
    $page = isset($_GET['page']) ? $_GET['page'] : 'home';
    $level = $_SESSION['user']['level'];
?>
<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>Perpustakaan Digital</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link href="css/theme.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark">
            <a class="navbar-brand ps-3" href="index.php">Perpustakaan</a>
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" type="button"><i class="fas fa-bars"></i></button>
            <div class="d-none d-md-flex ms-auto me-3 topnav-user"><?php echo htmlspecialchars($_SESSION['user']['nama']); ?></div>
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="logout.php">Keluar</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Utama</div>
                            <a class="nav-link<?php echo ($page === 'home') ? ' active' : ''; ?>" href="index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-th-large"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Koleksi</div>
                            <?php if($level != 'peminjam'){ ?>
                            <a class="nav-link<?php echo ($page === 'katagori' || $page === 'katagori_tambah' || $page === 'katagori_ubah') ? ' active' : ''; ?>" href="?page=katagori">
                                <div class="sb-nav-link-icon"><i class="fas fa-folder"></i></div>
                                Kategori
                            </a>
                            <a class="nav-link<?php echo ($page === 'buku' || $page === 'buku_tambah' || $page === 'buku_ubah') ? ' active' : ''; ?>" href="?page=buku">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                Buku
                            </a>
                            <?php } else { ?>
                            <a class="nav-link<?php echo ($page === 'peminjaman') ? ' active' : ''; ?>" href="?page=peminjaman">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Peminjaman
                            </a>
                            <?php } ?>
                            <a class="nav-link<?php echo ($page === 'ulasan' || $page === 'ulasan_tambah' || $page === 'ulasan_ubah') ? ' active' : ''; ?>" href="?page=ulasan">
                                <div class="sb-nav-link-icon"><i class="fas fa-comment"></i></div>
                                Ulasan
                            </a>
                            <a class="nav-link<?php echo ($page === 'laporan') ? ' active' : ''; ?>" href="?page=laporan">
                                <div class="sb-nav-link-icon"><i class="fas fa-file-lines"></i></div>
                                Laporan
                            </a>
                            <div class="sb-sidenav-menu-heading">Akun</div>
                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-power-off"></i></div>
                                Keluar
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Login sebagai</div>
                        <?php echo htmlspecialchars($_SESSION['user']['nama']); ?>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php
                            if(file_exists($page . '.php')){
                                include $page . '.php';
                            }else{
                                include '404.php';
                            }
                        ?>
                    </div>
                </main>
                <footer class="py-3 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Perpustakaan Digital</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
