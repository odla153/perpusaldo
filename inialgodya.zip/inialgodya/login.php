<?php
    include "koneksi.php";
?>
<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>Masuk — Perpustakaan Digital</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link href="css/theme.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
    <body class="app-auth">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card mt-5">
                                    <div class="card-header py-4">
                                        <h3 class="text-center">Masuk</h3>
                                        <p class="text-center page-sub mb-0">Perpustakaan Digital</p>
                                    </div>
                                    <div class="card-body p-4">
                                        <?php
                                            if(isset($_POST['login'])) {
                                                $username = $_POST['username'];
                                                if (isset($_POST['password'])) {
                                                $password = md5($_POST['password']);

                                                    $data = mysqli_query($koneksi, "SELECT*FROM user where username='$username' and password='$password'");
                                                    $cek = mysqli_num_rows($data);
                                                    if($cek > 0 ){
                                                    $_SESSION['user'] = mysqli_fetch_array($data);
                                                    echo '<script>Swal.fire({title: "Berhasil", text: "Anda telah masuk.", icon: "success"}).then(() => {setTimeout(() => {location.href = "index.php";}, 500);});</script>';
                                                    }else{

                                                    echo '<script>Swal.fire({title: "Gagal", text: "Username atau password salah.", icon: "error"});</script>';
                                                    }
                                                }
                                            }
                                        ?>
                                        <form method="post">
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputEmail" type="text" name="username" placeholder="Username" />
                                                <label for="inputEmail">Username</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputPassword" type="password" name="password" placeholder="Password" />
                                                <label for="inputPassword">Password</label>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <button class="btn btn-primary px-4" type="submit" name="login" value="login">Masuk</button>
                                                <a class="btn btn-secondary" href="register.php">Daftar</a>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        <div class="small">&copy; <?php echo date('Y'); ?> Perpustakaan</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
