<?php
    $nKatagori = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM katagori"));
    $nBuku = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku"));
    $nUlasan = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM ulasan"));
    $nUser = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM user"));
?>
<h1 class="mt-4">Dashboard</h1>
<p class="page-sub mb-4">Ringkasan koleksi dan akun.</p>
<div class="row g-3">
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <span class="stat-label">Kategori</span>
            <span class="stat-value"><?php echo $nKatagori; ?></span>
            <a href="?page=katagori">Lihat data</a>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <span class="stat-label">Buku</span>
            <span class="stat-value"><?php echo $nBuku; ?></span>
            <a href="?page=buku">Lihat data</a>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <span class="stat-label">Ulasan</span>
            <span class="stat-value"><?php echo $nUlasan; ?></span>
            <a href="?page=ulasan">Lihat data</a>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card">
            <span class="stat-label">Pengguna</span>
            <span class="stat-value"><?php echo $nUser; ?></span>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-body">
        <table class="table profile-table mb-0">
            <tr>
                <td>Nama</td>
                <td><?php echo htmlspecialchars($_SESSION['user']['nama']); ?></td>
            </tr>
            <tr>
                <td>Jabatan</td>
                <td><?php echo htmlspecialchars($_SESSION['user']['level']); ?></td>
            </tr>
            <tr>
                <td>Tanggal</td>
                <td><?php echo date('d-m-Y'); ?></td>
            </tr>
        </table>
    </div>
</div>
